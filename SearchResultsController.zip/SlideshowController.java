package photos.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import photos.model.Album;
import photos.model.Photo;
import photos.model.User;

import java.io.File;
import java.util.List;

/**
 * Controller for the manual slideshow screen (slideshow.fxml).
 * Allows the user to navigate through all photos in the current album
 * one at a time, forward and backward.
 * The Previous button is disabled at index 0 and the Next button is
 * disabled at the last index.
 *
 * @author YourName
 */
public class SlideshowController {

    @FXML private ImageView photoImageView;
    @FXML private Label     captionLabel;
    @FXML private Label     indexLabel;
    @FXML private Button    prevButton;
    @FXML private Button    nextButton;

    private User        currentUser;
    private Album       currentAlbum;
    private List<Photo> photos;
    private int         currentIndex;

    /**
     * Injects context and navigates to the starting photo.
     * Called by {@link AlbumController} after the scene is loaded.
     *
     * @param user       the logged-in {@link User}
     * @param album      the {@link Album} being shown
     * @param startIndex the zero-based index of the first photo to display
     */
    public void setContext(User user, Album album, int startIndex) {
        this.currentUser  = user;
        this.currentAlbum = album;
        this.photos       = album.getPhotos();
        this.currentIndex = startIndex;
        displayCurrentPhoto();
    }

    /**
     * Renders the photo at {@link #currentIndex} and updates all UI controls.
     * Disables the Previous button when at index 0 and the Next button
     * when at the last photo. If the image file cannot be loaded, the
     * {@link ImageView} is cleared rather than crashing.
     */
    private void displayCurrentPhoto() {
        Photo photo = photos.get(currentIndex);

        try {
            File f = new File(photo.getFilePath());
            photoImageView.setImage(new Image(f.toURI().toString()));
            photoImageView.setPreserveRatio(true);
        } catch (Exception e) {
            photoImageView.setImage(null);
        }

        captionLabel.setText(photo.getCaption().isBlank()
                ? "(no caption)" : photo.getCaption());

        indexLabel.setText((currentIndex + 1) + " / " + photos.size());

        prevButton.setDisable(currentIndex == 0);
        nextButton.setDisable(currentIndex == photos.size() - 1);
    }

    /**
     * Handles the Previous button.
     * Decrements {@link #currentIndex} and refreshes the display.
     * Does nothing if already at the first photo.
     */
    @FXML
    private void handlePrev() {
        if (currentIndex > 0) {
            currentIndex--;
            displayCurrentPhoto();
        }
    }

    /**
     * Handles the Next button.
     * Increments {@link #currentIndex} and refreshes the display.
     * Does nothing if already at the last photo.
     */
    @FXML
    private void handleNext() {
        if (currentIndex < photos.size() - 1) {
            currentIndex++;
            displayCurrentPhoto();
        }
    }

    /**
     * Handles the Back button.
     * Returns to the album view screen for the current album.
     */
    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/photos/view/album.fxml"));
            Parent root = loader.load();

            AlbumController controller = loader.getController();
            controller.setContext(currentUser, currentAlbum);

            Stage stage = (Stage) photoImageView.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(currentAlbum.getName());
            stage.show();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Failed to return to album.");
            alert.showAndWait();
        }
    }
}
