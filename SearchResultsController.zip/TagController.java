package photos.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Stage;
import photos.model.Album;
import photos.model.DataManager;
import photos.model.Photo;
import photos.model.Tag;
import photos.model.User;
import photos.model.UserManager;

import java.util.Optional;

/**
 * Controller for the tag editor screen (tagEditor.fxml).
 * Allows the user to add tags to a photo by selecting a type from a
 * {@link ComboBox} and entering a value. Supports defining new tag types
 * (with single or multi-value semantics) via an inline option in the ComboBox.
 * Existing tags are shown in a {@link ListView} and can be deleted individually.
 *
 * @author YourName
 */
public class TagController {

    @FXML private ComboBox<String> tagTypeComboBox;
    @FXML private TextField        tagValueField;
    @FXML private ListView<Tag>    tagListView;

    private User  currentUser;
    private Album currentAlbum;
    private Photo currentPhoto;

    /** Sentinel item shown at the bottom of the tag type ComboBox. */
    private static final String ADD_NEW_TYPE = "+ Add new tag type...";

    /**
     * Injects context and populates the tag type ComboBox and tag list.
     * Registers a listener on the ComboBox so that selecting the
     * {@code ADD_NEW_TYPE} sentinel triggers the new-type dialog.
     *
     * @param user  the logged-in {@link User}
     * @param album the {@link Album} being viewed
     * @param photo the {@link Photo} whose tags are being managed
     */
    public void setContext(User user, Album album, Photo photo) {
        this.currentUser  = user;
        this.currentAlbum = album;
        this.currentPhoto = photo;

        refreshTagTypes();
        refreshTagList();

        tagTypeComboBox.setOnAction(e -> {
            if (ADD_NEW_TYPE.equals(tagTypeComboBox.getValue())) {
                handleAddNewTagType();
            }
        });
    }

    /**
     * Rebuilds the tag type {@link ComboBox} from the user's current tag type list.
     * Always appends {@link #ADD_NEW_TYPE} as the final item.
     * Resets the selection to the first real type, or {@code null} if none exist.
     */
    private void refreshTagTypes() {
        tagTypeComboBox.getItems().setAll(currentUser.getTagTypes());
        tagTypeComboBox.getItems().add(ADD_NEW_TYPE);
        tagTypeComboBox.setValue(currentUser.getTagTypes().isEmpty()
                ? null : currentUser.getTagTypes().get(0));
    }

    /**
     * Rebuilds the tag {@link ListView} from the photo's current tag list.
     * Each cell displays the tag via {@link Tag#toString()} (e.g. "person=Susan").
     */
    private void refreshTagList() {
        tagListView.setItems(
                FXCollections.observableArrayList(currentPhoto.getTags()));
    }

    /**
     * Handles the Add Tag button.
     * Reads the selected type from the ComboBox and the value from the text field,
     * then delegates to {@link Photo#addTag(Tag, java.util.List)}.
     * Rejects blank values, the sentinel item, and violations of single-value
     * or duplicate-tag constraints.
     */
    @FXML
    private void handleAddTag() {
        String type  = tagTypeComboBox.getValue();
        String value = tagValueField.getText().trim();

        if (type == null || type.equals(ADD_NEW_TYPE)) {
            showAlert("Please select a valid tag type.");
            return;
        }
        if (value.isBlank()) {
            showAlert("Please enter a tag value.");
            return;
        }

        boolean added = currentPhoto.addTag(
                new Tag(type, value),
                currentUser.getSingleValueTagTypes());

        if (!added) {
            showAlert("This tag already exists on the photo, " +
                      "or this type only allows one value per photo.");
        } else {
            tagValueField.clear();
            refreshTagList();
            DataManager.saveUsers(UserManager.getInstance());
        }
    }

    /**
     * Handles the Delete Tag button.
     * Asks for confirmation before removing the selected tag from the photo.
     * The deletion is reflected in all albums sharing this photo instance.
     */
    @FXML
    private void handleDeleteTag() {
        Tag selected = tagListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a tag to delete.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Tag");
        confirm.setHeaderText(null);
        confirm.setContentText("Delete tag '" + selected + "'?");

        Optional<ButtonType> response = confirm.showAndWait();
        if (response.isPresent() && response.get() == ButtonType.OK) {
            currentPhoto.removeTag(selected);
            refreshTagList();
            DataManager.saveUsers(UserManager.getInstance());
        }
    }

    /**
     * Prompts the user to define a new tag type.
     * First asks for the type name via {@link TextInputDialog}, then asks
     * whether the type should allow only one value per photo via a custom
     * {@link Alert} with two option buttons.
     * Adds the type to the user's list and refreshes the ComboBox on success.
     * Resets the ComboBox selection if the user cancels at any step.
     */
    private void handleAddNewTagType() {
        // Step 1: get the type name
        TextInputDialog nameDialog = new TextInputDialog();
        nameDialog.setTitle("New Tag Type");
        nameDialog.setHeaderText(null);
        nameDialog.setContentText("Enter new tag type name:");

        Optional<String> nameResult = nameDialog.showAndWait();
        if (nameResult.isEmpty() || nameResult.get().isBlank()) {
            resetComboBoxSelection();
            return;
        }

        String newType = nameResult.get().trim();

        // Step 2: single-value or multi-value?
        Alert singleValueAlert = new Alert(Alert.AlertType.CONFIRMATION);
        singleValueAlert.setTitle("Tag Value Policy");
        singleValueAlert.setHeaderText(null);
        singleValueAlert.setContentText(
                "Should '" + newType + "' allow only one value per photo?\n" +
                "e.g. 'location' is single-value; 'person' is multi-value.");
        singleValueAlert.getButtonTypes().setAll(
                new ButtonType("Single value"),
                new ButtonType("Multiple values"),
                ButtonType.CANCEL);

        Optional<ButtonType> response = singleValueAlert.showAndWait();
        if (response.isEmpty() || response.get() == ButtonType.CANCEL) {
            resetComboBoxSelection();
            return;
        }

        boolean isSingle = response.get().getText().equals("Single value");
        boolean added    = currentUser.addTagType(newType, isSingle);

        if (!added) {
            showAlert("Tag type '" + newType + "' already exists.");
            resetComboBoxSelection();
        } else {
            DataManager.saveUsers(UserManager.getInstance());
            refreshTagTypes();
            tagTypeComboBox.setValue(newType);
        }
    }

    /**
     * Resets the ComboBox selection to the first real tag type (or null if none),
     * used when the user cancels out of the new-type dialog.
     */
    private void resetComboBoxSelection() {
        tagTypeComboBox.setValue(currentUser.getTagTypes().isEmpty()
                ? null : currentUser.getTagTypes().get(0));
    }

    /**
     * Handles the Back button.
     * Returns to the album view screen.
     */
    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/photos/view/album.fxml"));
            Parent root = loader.load();

            AlbumController controller = loader.getController();
            controller.setContext(currentUser, currentAlbum);

            Stage stage = (Stage) tagListView.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(currentAlbum.getName());
            stage.show();
        } catch (Exception e) {
            showAlert("Failed to return to album.");
        }
    }

    /**
     * Displays an error {@link Alert} with the given message.
     *
     * @param message the error text to display
     */
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Tag Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
