package photos.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import photos.model.Album;
import photos.model.DataManager;
import photos.model.Photo;
import photos.model.User;
import photos.model.UserManager;

import java.io.File;
import java.util.Optional;

/**
 * Controller for the album view screen (album.fxml).
 * Displays all photos in the current album as a scrollable thumbnail list.
 * Each cell shows a 100×100 thumbnail and the photo's caption.
 * Supports adding, removing, captioning, displaying, tagging,
 * copying, moving, and slideshowing photos.
 *
 * @author YourName
 */
public class AlbumController {

    @FXML private ListView<Photo> photoListView;
    @FXML private Label albumNameLabel;

    private User  currentUser;
    private Album currentAlbum;
    private ObservableList<Photo> observablePhotos;

    /**
     * Injected by the previous controller after the scene is loaded.
     * Sets the active user and album, then populates the photo list.
     *
     * @param user  the logged-in {@link User}
     * @param album the {@link Album} being viewed
     */
    public void setContext(User user, Album album) {
        this.currentUser  = user;
        this.currentAlbum = album;
        albumNameLabel.setText(album.getName());
        observablePhotos = FXCollections.observableArrayList(album.getPhotos());
        photoListView.setItems(observablePhotos);
        setupCellFactory();
    }

    /**
     * Configures the {@link ListView} cell factory so each row renders
     * a 100×100 thumbnail {@link ImageView} above a caption {@link Label},
     * stacked in a {@link VBox}. Missing or unloadable images are shown
     * as an empty image slot rather than crashing.
     */
    private void setupCellFactory() {
        photoListView.setCellFactory(lv -> new ListCell<>() {
            private final ImageView thumbnail = new ImageView();
            private final Label     caption   = new Label();
            private final VBox      cell      = new VBox(4, thumbnail, caption);

            {
                thumbnail.setFitWidth(100);
                thumbnail.setFitHeight(100);
                thumbnail.setPreserveRatio(true);
            }

            @Override
            protected void updateItem(Photo photo, boolean empty) {
                super.updateItem(photo, empty);
                if (empty || photo == null) {
                    setGraphic(null);
                } else {
                    try {
                        File f = new File(photo.getFilePath());
                        thumbnail.setImage(
                                new Image(f.toURI().toString(), 100, 100, true, true));
                    } catch (Exception e) {
                        thumbnail.setImage(null);
                    }
                    caption.setText(photo.getCaption().isBlank()
                            ? "(no caption)" : photo.getCaption());
                    setGraphic(cell);
                }
            }
        });
    }

    /**
     * Synchronises the observable photo list with the album's current state.
     * Called after every mutation to keep the {@link ListView} in sync.
     */
    private void refreshList() {
        observablePhotos.setAll(currentAlbum.getPhotos());
    }

    /**
     * Handles the Add Photo button.
     * Opens a {@link FileChooser} filtered to BMP, GIF, JPEG, and PNG formats.
     * Creates a {@link Photo} from the selected file and adds it to the album.
     * Rejects photos already present in this album.
     */
    @FXML
    private void handleAddPhoto() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Select Photo");
        chooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter(
                        "Image Files", "*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp"));

        File file = chooser.showOpenDialog(photoListView.getScene().getWindow());
        if (file == null) return;

        try {
            Photo photo = new Photo(file.getAbsolutePath());
            boolean added = currentAlbum.addPhoto(photo);
            if (!added) {
                showAlert("That photo is already in this album.");
            } else {
                refreshList();
                DataManager.saveUsers(UserManager.getInstance());
            }
        } catch (IllegalArgumentException e) {
            showAlert("Could not load photo: " + e.getMessage());
        }
    }

    /**
     * Handles the Remove Photo button.
     * Confirms removal before deleting the selected photo's reference
     * from this album. The {@link Photo} object persists in any other
     * albums that also reference it.
     */
    @FXML
    private void handleRemovePhoto() {
        Photo selected = photoListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a photo to remove.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Remove Photo");
        confirm.setHeaderText(null);
        confirm.setContentText(
                "Remove this photo from the album? " +
                "It will not be deleted from other albums.");

        Optional<ButtonType> response = confirm.showAndWait();
        if (response.isPresent() && response.get() == ButtonType.OK) {
            currentAlbum.removePhoto(selected);
            refreshList();
            DataManager.saveUsers(UserManager.getInstance());
        }
    }

    /**
     * Handles the Caption button.
     * Pre-fills the current caption in a {@link TextInputDialog} and
     * updates the selected photo on confirmation.
     * Because photos are shared by reference, the new caption is
     * immediately reflected in all albums containing this photo.
     */
    @FXML
    private void handleCaption() {
        Photo selected = photoListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a photo to caption.");
            return;
        }

        TextInputDialog dialog = new TextInputDialog(selected.getCaption());
        dialog.setTitle("Caption Photo");
        dialog.setHeaderText(null);
        dialog.setContentText("Enter caption:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(caption -> {
            selected.setCaption(caption);
            refreshList();
            DataManager.saveUsers(UserManager.getInstance());
        });
    }

    /**
     * Handles the Display button.
     * Navigates to the full photo display screen for the selected photo.
     */
    @FXML
    private void handleDisplayPhoto() {
        Photo selected = photoListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a photo to display.");
            return;
        }
        loadPhotoDisplayScene(selected);
    }

    /**
     * Handles mouse click events on the photo {@link ListView}.
     * Opens the photo display screen on a primary-button double-click.
     *
     * @param event the mouse event fired by the ListView
     */
    @FXML
    private void handlePhotoDoubleClick(MouseEvent event) {
        if (event.getButton() == MouseButton.PRIMARY && event.getClickCount() == 2) {
            Photo selected = photoListView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                loadPhotoDisplayScene(selected);
            }
        }
    }

    /**
     * Handles the Add Tag button.
     * Navigates to the tag editor screen for the selected photo.
     */
    @FXML
    private void handleAddTag() {
        Photo selected = photoListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a photo to tag.");
            return;
        }
        loadTagScene(selected);
    }

    /**
     * Handles the Delete Tag button.
     * Navigates to the tag editor screen (which handles both add and delete)
     * for the selected photo.
     */
    @FXML
    private void handleDeleteTag() {
        Photo selected = photoListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a photo to manage tags.");
            return;
        }
        loadTagScene(selected);
    }

    /**
     * Handles the Copy button.
     * Navigates to the copy/move screen in copy mode for the selected photo.
     */
    @FXML
    private void handleCopyPhoto() {
        Photo selected = photoListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a photo to copy.");
            return;
        }
        loadCopyMoveScene(selected, false);
    }

    /**
     * Handles the Move button.
     * Navigates to the copy/move screen in move mode for the selected photo.
     */
    @FXML
    private void handleMovePhoto() {
        Photo selected = photoListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a photo to move.");
            return;
        }
        loadCopyMoveScene(selected, true);
    }

    /**
     * Handles the Slideshow button.
     * Opens the slideshow screen starting at the currently selected photo,
     * or at the first photo if none is selected.
     * Shows an error if the album has no photos.
     */
    @FXML
    private void handleSlideshow() {
        if (currentAlbum.getPhotoCount() == 0) {
            showAlert("This album has no photos to show.");
            return;
        }

        int startIndex = photoListView.getSelectionModel().getSelectedIndex();
        if (startIndex < 0) startIndex = 0;

        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/photos/view/slideshow.fxml"));
            Parent root = loader.load();

            SlideshowController controller = loader.getController();
            controller.setContext(currentUser, currentAlbum, startIndex);

            Stage stage = (Stage) photoListView.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Slideshow — " + currentAlbum.getName());
            stage.show();
        } catch (Exception e) {
            showAlert("Failed to open slideshow.");
        }
    }

    /**
     * Handles the Back button.
     * Saves data and returns to the album list screen.
     */
    @FXML
    private void handleBack() {
        DataManager.saveUsers(UserManager.getInstance());
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/photos/view/albumList.fxml"));
            Parent root = loader.load();

            AlbumListController controller = loader.getController();
            controller.setUser(currentUser);

            Stage stage = (Stage) photoListView.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Photos");
            stage.show();
        } catch (Exception e) {
            showAlert("Failed to return to album list.");
        }
    }

    /**
     * Loads the photo display scene and injects user, album, and photo context.
     *
     * @param photo the {@link Photo} to display
     */
    private void loadPhotoDisplayScene(Photo photo) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/photos/view/photoDisplay.fxml"));
            Parent root = loader.load();

            PhotoDisplayController controller = loader.getController();
            controller.setContext(currentUser, currentAlbum, photo);

            Stage stage = (Stage) photoListView.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Photo — " + (photo.getCaption().isBlank()
                    ? "Untitled" : photo.getCaption()));
            stage.show();
        } catch (Exception e) {
            showAlert("Failed to open photo display.");
        }
    }

    /**
     * Loads the tag editor scene and injects user, album, and photo context.
     *
     * @param photo the {@link Photo} whose tags will be edited
     */
    private void loadTagScene(Photo photo) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/photos/view/tagEditor.fxml"));
            Parent root = loader.load();

            TagController controller = loader.getController();
            controller.setContext(currentUser, currentAlbum, photo);

            Stage stage = (Stage) photoListView.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Tags — " + (photo.getCaption().isBlank()
                    ? "Photo" : photo.getCaption()));
            stage.show();
        } catch (Exception e) {
            showAlert("Failed to open tag editor.");
        }
    }

    /**
     * Loads the copy/move scene and injects context including the operation mode.
     *
     * @param photo  the {@link Photo} to copy or move
     * @param isMove {@code true} to move, {@code false} to copy
     */
    private void loadCopyMoveScene(Photo photo, boolean isMove) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/photos/view/copyMove.fxml"));
            Parent root = loader.load();

            CopyMoveController controller = loader.getController();
            controller.setContext(currentUser, currentAlbum, photo, isMove);

            Stage stage = (Stage) photoListView.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(isMove ? "Move Photo" : "Copy Photo");
            stage.show();
        } catch (Exception e) {
            showAlert("Failed to open copy/move dialog.");
        }
    }

    /**
     * Displays an error {@link Alert} with the given message.
     *
     * @param message the error text to display
     */
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
