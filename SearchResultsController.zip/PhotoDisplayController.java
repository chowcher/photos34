package photos.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import photos.model.Album;
import photos.model.Photo;
import photos.model.Tag;
import photos.model.User;

import java.io.File;
import java.text.SimpleDateFormat;

/**
 * Controller for the single-photo display screen (photoDisplay.fxml).
 * Renders the photo at full size alongside its caption, capture date,
 * and a list of all attached tags.
 * The photo is displayed with its aspect ratio preserved.
 *
 * @author YourName
 */
public class PhotoDisplayController {

    @FXML private ImageView     photoImageView;
    @FXML private Label         captionLabel;
    @FXML private Label         dateLabel;
    @FXML private ListView<Tag> tagListView;

    private User  currentUser;
    private Album currentAlbum;
    private Photo currentPhoto;

    /**
     * Populates all UI fields for the given photo.
     * Called by the previous controller after the scene is loaded.
     * If the image file cannot be read, the caption label shows a fallback message.
     *
     * @param user  the logged-in {@link User}
     * @param album the {@link Album} this photo was opened from
     * @param photo the {@link Photo} to display
     */
    public void setContext(User user, Album album, Photo photo) {
        this.currentUser  = user;
        this.currentAlbum = album;
        this.currentPhoto = photo;

        // Load image
        try {
            File f = new File(photo.getFilePath());
            photoImageView.setImage(new Image(f.toURI().toString()));
            photoImageView.setPreserveRatio(true);
        } catch (Exception e) {
            captionLabel.setText("Image could not be loaded.");
        }

        // Caption
        captionLabel.setText(photo.getCaption().isBlank()
                ? "(no caption)" : photo.getCaption());

        // Capture date — formatted as "January 05, 2024  02:30 PM"
        SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy  hh:mm a");
        dateLabel.setText(sdf.format(photo.getCaptureDate().getTime()));

        // Tags
        tagListView.getItems().setAll(photo.getTags());
    }

    /**
     * Handles the Back button.
     * Returns to the album view for the album this photo was opened from.
     */
    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/photos/view/album.fxml"));
            Parent root = loader.load();

            AlbumController controller = loader.getController();
            controller.setContext(currentUser, currentAlbum);

            Stage stage = (Stage) photoImageView.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(currentAlbum.getName());
            stage.show();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Failed to return to album.");
            alert.showAndWait();
        }
    }
}
